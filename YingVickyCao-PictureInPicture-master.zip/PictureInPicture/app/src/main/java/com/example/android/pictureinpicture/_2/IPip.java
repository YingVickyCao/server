package com.example.android.pictureinpicture._2;

public interface IPip {
    void onRestart();

    void onUserLeaveHint();

    void onWindowFocusChanged(boolean hasFocus);
}
