package com.example.android.pictureinpicture._2;

public class PrepareDestroyAppEvent {
}
