# ServerMocker

# 1 介绍

模拟一个 server，以供 client 测试

# 2 安装教程

## Local NodeJS Server

https://www.runoob.com/nodejs/nodejs-install-setup.html

## Server Created by Spring Boot

folder `server`

# 3 使用说明

## Local NodeJS Server

- Mock get

```
node node node_js_get.js
```

http://127.0.0.1:7777/getSum?num1=5&num2=15

- Mock post

node_js_post.js
