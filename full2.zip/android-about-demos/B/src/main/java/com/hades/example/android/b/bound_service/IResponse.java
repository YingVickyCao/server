package com.hades.example.android.b.bound_service;

public interface IResponse {
    void setData(String data);
}