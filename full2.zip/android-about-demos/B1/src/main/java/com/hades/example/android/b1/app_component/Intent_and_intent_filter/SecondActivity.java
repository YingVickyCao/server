package com.hades.example.android.b1.app_component.Intent_and_intent_filter;

public class SecondActivity extends TestReceiveImplicitIntentActivity {
}