package com.hades.example.android;

public class BConstant {
    public final static String B_REMOTEBOUNDEDSERVICE_CLASS = "com.hades.example.android.b.bound_service.RemoteBoundedService";
    public final static String B_REMOTEBOUNDEDSERVICE_CLASS_ACTION = B_REMOTEBOUNDEDSERVICE_CLASS;
    public final static String B_PACKAGE = "com.hades.example.android.b";
}