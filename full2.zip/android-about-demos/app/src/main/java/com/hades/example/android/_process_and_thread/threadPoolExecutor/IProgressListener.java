package com.hades.example.android._process_and_thread.threadPoolExecutor;

public interface IProgressListener {
    void update(String counter);
}