package com.hades.example.android.app_component._intent_and_intent_filter._data_type;

public class B15 extends BBase {
    @Override
    protected String getPageName() {
        return B15.class.getSimpleName();
    }
}