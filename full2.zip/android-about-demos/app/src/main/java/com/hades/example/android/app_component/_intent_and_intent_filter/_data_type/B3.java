package com.hades.example.android.app_component._intent_and_intent_filter._data_type;

public class B3 extends BBase {
    @Override
    protected String getPageName() {
        return B3.class.getSimpleName();
    }
}