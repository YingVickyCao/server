package com.hades.example.android.app_component._intent_and_intent_filter._data_type;

public class B5 extends BBase {
    @Override
    protected String getPageName() {
        return B5.class.getSimpleName();
    }
}
