package com.hades.example.android.app_component._intent_and_intent_filter._flag;

public class E extends D {
    private static final String TAG = E.class.getSimpleName();

    private final String NAME_E = "E";

    @Override
    protected String getTag() {
        return TAG;
    }

    @Override
    protected String getName() {
        return NAME_E;
    }
}
