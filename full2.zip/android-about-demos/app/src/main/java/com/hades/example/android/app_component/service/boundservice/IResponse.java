package com.hades.example.android.app_component.service.boundservice;

public interface IResponse {
    void setData(String data);
}
