package com.hades.example.android.media.record.audio;

import android.app.Activity;

public class TestRecordVideoActivity extends Activity {
}
