
package com.hades.example.android.other_ui._dialog.good.activity;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.Nullable;

import com.hades.example.android.R;

public class DialogStyleActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.other_ui_dialog_style_activity);
    }
}