package com.hades.example.android.other_ui._notification;

import android.app.Activity;
import android.os.Bundle;

import com.hades.example.android.R;

public class TestNotificationDescActivity extends Activity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.other_ui_notification_desc);
    }
}