package com.hades.example.android.other_ui.manager_phone_desktop._app_widget.list;

public class WidgetItem {
    int color;

    public WidgetItem(int color) {
        this.color = color;
    }

    public int getColor() {
        return color;
    }
}
