package com.hades.example.android.other_ui.manager_phone_desktop.shortcuts._static;

import android.app.Activity;
import android.os.Bundle;

import com.hades.example.android.R;

public class StaticShortcutsActionResponseActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.static_shorts_action_response_layout);
    }
}

