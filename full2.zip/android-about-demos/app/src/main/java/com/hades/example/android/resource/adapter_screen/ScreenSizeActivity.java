package com.hades.example.android.resource.adapter_screen;


import android.app.Activity;
import android.os.Bundle;

import com.hades.example.android.R;

public class ScreenSizeActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.res_screen_size);
    }
}