package com.hades.example.android.resource.drawable.alpha;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.Nullable;

import com.hades.example.android.R;

public class AttributeActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.res_attribution);
    }
}
