package com.hades.example.android.widget._list._recyclerview._dag_reorder_list.v2;

public class Child {
    public String childText;

    public Child(String childText) {
        this.childText = childText;
    }
}