package com.hades.example.android.widget._list._recyclerview._dag_reorder_list.v2;

public interface IItemViewHolder {
    void onItemSelected();

    void onItemClear();
}