package com.hades.example.android.widget._list._recyclerview.dummy;


import com.github.yingvickycao.autils.mock.DummyItem;

public interface IItemClickAction {
    void onItemClickListener(DummyItem item);
}
